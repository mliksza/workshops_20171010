library(shiny)
library(DT)
library(plotly)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("IMDb data analysis"),
  
  # Sidebar with widgets
  sidebarLayout(
    sidebarPanel(
      selectizeInput(inputId = "title_type",
                     label = "Choose title type to analyze: ",
                     choices = c("movie" = "movie",
                                 "short" = "short",
                                 "tvEpisode" = "tvEpisode",
                                 "tvMiniSeries" = "tvMiniSeries",
                                 "tvMovie" = "tvMovie",
                                 "tvSeries" = "tvSeries",
                                 "tvShort" = "tvShort",
                                 "tvSpecial" = "tvSpecial",
                                 "video" = "video",
                                 "videoGame" = "videoGame"
                                ),
                     selected = c("movie") ,
                     multiple = FALSE),
      selectizeInput(inputId = "genre",
                     label = "Choose genres to analyze: ",
                     choices = c("Action" = "Action",
                                 "Adult" = "Adult",
                                 "Adventure" = "Adventure",
                                 "Animation" = "Animation",
                                 "Biography" = "Biography",
                                 "Comedy" = "Comedy",
                                 "Crime" = "Crime",
                                 "Documentary" = "Documentary",
                                 "Drama" = "Drama",
                                 "Family" = "Family",
                                 "Fantasy" = "Fantasy",
                                 "Film-Noir" = "Film-Noir",
                                 "Game-Show" = "Game-Show",
                                 "History" = "History",
                                 "Horror" = "Horror",
                                 "Music" = "Music",
                                 "Musical" = "Musical",
                                 "Mystery" = "Mystery",
                                 "News" = "News",
                                 "Reality-TV" = "Reality-TV",
                                 "Romance" = "Romance",
                                 "Sci-Fi" = "Sci-Fi",
                                 "Short" = "Short",
                                 "Sport" = "Sport",
                                 "Talk-Show" = "Talk-Show",
                                 "Thriller" = "Thriller",
                                 "War" = "War",
                                 "Western" = "Western"),
                     selected = c("Action", "Adult", "Adventure", "Animation", "Biography", "Comedy",     
                                  "Crime", "Documentary", "Drama", "Family", "Fantasy", "Film-Noir",  
                                  "Game-Show", "History", "Horror", "Music", "Musical", "Mystery",    
                                  "News", "Reality-TV", "Romance", "Sci-Fi", "Short",      
                                  "Sport", "Talk-Show", "Thriller", "War", "Western") ,
                     multiple = TRUE),
      sliderInput("top_n", label = h3("Top n"), min = 1, 
                  max = 100, value = 10),
      sliderInput("votes", label = h3("Votes range"), min = 100, 
                  max = 10000, value = c(400, 5000)),
      selectInput(
        inputId =  "date_from", 
        label = "Start year:", 
        choices = 1874:2018,
        selected = 1874
      ),
      selectInput(
        inputId =  "date_to", 
        label = "End year:", 
        choices = 1874:2018,
        selected = 2018
      )
      
    ),
    
    # Show plot and table data after filtering
    mainPanel(
       plotlyOutput("plot_top_n_per_genre"),
       div(style ='overflow-x: scroll; font-size:85%',
           DT::dataTableOutput('tbl_top_n_per_genre'))
    )
  )
))
