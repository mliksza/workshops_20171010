library(shiny)
library(tidyverse)
library(glmnet)
library(splitstackshape)
library(plotly)
library(ggplot2)
library(DT)


shinyServer(function(input, output) {


  film_rates <- read_tsv("data/films_rates_last.tsv")

  # rename columns
  names(film_rates) <- sub(".*_last.", "", names(film_rates))
  
  # make factor
  film_rates$titletype <- as.factor(film_rates$titletype)
  
  # make logical 
  film_rates$isadult <- as.logical(film_rates$isadult)
  
  # split into a few columns
  film_rates_splitted <- cSplit(film_rates, "genres", sep=",")
  
  ## dplyr usage ##
  film_rates_rem_na <- film_rates_splitted %>% 
    filter(!is.na(averagerating)) %>%  # remove records with NA values in averagerating
    select(-processing_dttm)

  # group by genre 
  top_n_per_genre <- reactive({  
    film_rates_rem_na %>%
      select(primarytitle, averagerating, numvotes, genres_1, titletype, startyear) %>%
      filter(numvotes <= 10000) %>% #remove outliers
      filter(numvotes >= input$votes[1] & 
             numvotes <= input$votes[2] &
             genres_1 %in% input$genre &
             titletype == input$title_type &
             startyear >= input$date_from &
             startyear <= input$date_to) %>%
      select(-titletype) %>%
      group_by(genres_1) %>%
      top_n(n = input$top_n, wt = averagerating) %>%
      arrange(genres_1, desc(averagerating)) 
  })
  

  
  # visualization 
  output$plot_top_n_per_genre <- renderPlotly({
    ggplotly(
      ggplot(top_n_per_genre(), aes(x = numvotes, y = averagerating, label = primarytitle)) +
        geom_point(aes(colour = genres_1)) 
    )
  })
  
  output$tbl_top_n_per_genre <- 
    DT::renderDataTable(
      datatable(
        top_n_per_genre(),
        extensions = 'Buttons', 
        options = list(
          dom = 'Blfrtip',
          lengthMenu = list(c(-1, 5, 10, 15, 20, 25), c('All', '5', '10', '15', '20', '25')),
          buttons = list('copy',
                         list(extend = 'excel',
                              filename = 'top_n_per_genre'),
                         'print'),
          server = FALSE
        ),
        rownames = FALSE,
        selection = 'multiple'
      ) 
    )

  
})
